"""Standalone dancing-face preview; does not connect to LViT or the learning app."""
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk


FRAMES = ("~(˘▾˘~)", "(~˘▾˘)~")
DEFAULT_DURATIONS = (0.4, 0.4)
HOTKEY_LABEL = "Ctrl + Alt + 숫자패드 1"


def parse_durations(values):
    if not isinstance(values, (list, tuple)) or len(values) != 2:
        raise ValueError("두 동작의 시간을 각각 0.1~10초로 입력하세요.")
    try:
        if any(isinstance(value, bool) for value in values):
            raise ValueError
        durations = [float(value) for value in values]
        if not all(0.1 <= value <= 10 for value in durations):
            raise ValueError
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError("두 동작의 시간을 각각 0.1~10초로 입력하세요.") from error
    return durations


class HotkeyListener:
    HOTKEY_ID = 1
    MODIFIERS = 0x4003  # MOD_NOREPEAT | MOD_CONTROL | MOD_ALT
    KEY = 0x61  # VK_NUMPAD1, not the number-row 1 key
    WM_HOTKEY = 0x0312
    WM_QUIT = 0x0012

    def __init__(self, events):
        self.events = events
        self.thread = None
        self.thread_id = None
        self._user32 = None
        self._stop = threading.Event()

    def start(self):
        if sys.platform != "win32":
            self.events.put(("status", "이 환경은 Windows 전역 단축키를 지원하지 않습니다. 버튼으로 시험할 수 있습니다."))
            return
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        registered = False
        user32 = None
        try:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            user32.RegisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32]
            user32.RegisterHotKey.restype = ctypes.c_int
            user32.UnregisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int]
            user32.UnregisterHotKey.restype = ctypes.c_int
            user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
            user32.PeekMessageW.restype = ctypes.c_int
            user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
            user32.GetMessageW.restype = ctypes.c_int
            user32.PostThreadMessageW.argtypes = [ctypes.c_uint32, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t]
            user32.PostThreadMessageW.restype = ctypes.c_int
            kernel32.GetCurrentThreadId.argtypes = []
            kernel32.GetCurrentThreadId.restype = ctypes.c_uint32

            message = wintypes.MSG()
            user32.PeekMessageW(ctypes.byref(message), None, 0, 0, 0)
            self._user32 = user32
            self.thread_id = kernel32.GetCurrentThreadId()
            if self._stop.is_set():
                return
            registered = bool(user32.RegisterHotKey(None, self.HOTKEY_ID, self.MODIFIERS, self.KEY))
            if not registered:
                error = ctypes.get_last_error()
                self.events.put(("status", f"단축키 등록 실패 (오류 {error}). 다른 프로그램에서 사용 중일 수 있습니다. 버튼으로 시험하세요."))
                return
            self.events.put(("status", f"전역 단축키 준비 완료: {HOTKEY_LABEL} · NumLock을 켜고 사용하세요."))
            while not self._stop.is_set():
                result = user32.GetMessageW(ctypes.byref(message), None, 0, 0)
                if result == -1:
                    self.events.put(("status", f"단축키 메시지 오류 {ctypes.get_last_error()}. 버튼으로 계속 시험할 수 있습니다."))
                    break
                if result == 0:
                    if not self._stop.is_set():
                        self.events.put(("status", "전역 단축키 대기가 종료됐습니다. 버튼으로 계속 시험할 수 있습니다."))
                    break
                if message.message == self.WM_HOTKEY and message.wParam == self.HOTKEY_ID:
                    self.events.put(("toggle", None))
        except Exception as error:
            self.events.put(("status", f"전역 단축키를 준비하지 못했습니다: {error}. 버튼으로 시험할 수 있습니다."))
        finally:
            if registered:
                try:
                    user32.UnregisterHotKey(None, self.HOTKEY_ID)
                except Exception as error:
                    self.events.put(("status", f"단축키 해제 중 오류: {error}"))
            self.thread_id = None
            self._user32 = None

    def close(self):
        self._stop.set()
        user32, thread_id = self._user32, self.thread_id
        if user32 is not None and thread_id is not None:
            user32.PostThreadMessageW(thread_id, self.WM_QUIT, 0, 0)
        if self.thread is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)


class PreviewApp:
    def __init__(self, root, settings_path=None):
        self.root = root
        self.settings_path = Path(settings_path or Path(__file__).with_name("kaomoji-preview-settings.json"))
        self.events = queue.Queue()
        self.running = self.closed = False
        self.frame_index = 0
        self.frame_job = self.poll_job = None
        self.durations = list(DEFAULT_DURATIONS)
        self.status = tk.StringVar(root, value="시간 입력 후 Enter 또는 「시간 적용」을 누르세요.")
        try:
            if self.settings_path.exists():
                settings = json.loads(self.settings_path.read_text(encoding="utf-8"))
                self.durations = parse_durations(settings["durations"])
        except (OSError, ValueError, TypeError, KeyError):
            self.status.set("저장된 설정을 읽지 못해 기본값 각 0.4초로 시작합니다.")
        self.timing_vars = [tk.StringVar(root, value=f"{value:g}") for value in self.durations]
        self.save_settings = tk.BooleanVar(root, value=False)
        self.hotkey_status = tk.StringVar(root, value="전역 단축키 준비 중…")
        self._build()
        self.hotkeys = HotkeyListener(self.events)
        self.hotkeys.start()
        self.poll_job = root.after(50, self._poll)
        root.protocol("WM_DELETE_WINDOW", self.close)

    def _build(self):
        self.root.title("춤 모션 단축키 미리보기")
        self.root.geometry("700x460")
        self.root.minsize(580, 430)
        outer = ttk.Frame(self.root, padding=20)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="춤 모션 미리보기", font=("맑은 고딕", 18, "bold")).pack()
        self.face = ttk.Label(outer, text=FRAMES[0], font=("Consolas", 58), anchor="center")
        self.face.pack(fill="x", pady=22)
        timing = ttk.Frame(outer)
        timing.pack()
        for index, label in enumerate(("첫 동작(초)", "둘째 동작(초)")):
            ttk.Label(timing, text=label).grid(row=0, column=index * 2, padx=(6, 4))
            entry = ttk.Entry(timing, textvariable=self.timing_vars[index], width=7)
            entry.grid(row=0, column=index * 2 + 1)
            entry.bind("<Return>", lambda _event: self.apply_timing())
            entry.bind("<FocusOut>", lambda _event: self.apply_timing())
        ttk.Button(timing, text="시간 적용", command=self.apply_timing).grid(row=0, column=4, padx=8)
        ttk.Checkbutton(outer, text="설정 저장 (선택)", variable=self.save_settings, command=self.apply_timing).pack(pady=10)
        self.toggle_button = ttk.Button(outer, text="시작", command=self.toggle)
        self.toggle_button.pack(ipadx=28, ipady=5)
        ttk.Label(outer, textvariable=self.status, wraplength=540, justify="center").pack(pady=(10, 8))
        ttk.Label(outer, textvariable=self.hotkey_status, wraplength=540, justify="center").pack()
        ttk.Label(outer, text="숫자패드 1을 사용합니다. NumLock이 꺼져 있으면 End로 처리될 수 있습니다.", wraplength=540, justify="center").pack(pady=(7, 0))
        ttk.Label(outer, text="Windows 실기기 검증 전 미리보기 · LViT/학습 앱에는 적용되지 않습니다.", wraplength=540, justify="center").pack(pady=(7, 0))

    def apply_timing(self):
        try:
            values = parse_durations([variable.get() for variable in self.timing_vars])
        except ValueError as error:
            self.status.set(str(error))
            return False
        self.durations = values
        self._schedule_frame()
        self.status.set(f"첫 동작 {values[0]:g}초 · 둘째 동작 {values[1]:g}초")
        if self.save_settings.get():
            try:
                self.settings_path.write_text(json.dumps({"durations": values}, ensure_ascii=False), encoding="utf-8")
            except OSError as error:
                self.status.set(f"설정 저장 실패: {error}. 미리보기는 계속 사용할 수 있습니다.")
        return True

    def toggle(self):
        if self.closed:
            return
        if self.running:
            self.running = False
            self._schedule_frame()
            self.toggle_button.configure(text="시작")
            self.status.set("멈췄습니다.")
            return
        if self.apply_timing():
            self.running = True
            self.toggle_button.configure(text="정지")
            self._schedule_frame()

    def _schedule_frame(self):
        if self.frame_job is not None:
            self.root.after_cancel(self.frame_job)
            self.frame_job = None
        if self.running and not self.closed:
            self.frame_job = self.root.after(round(self.durations[self.frame_index] * 1000), self._advance)

    def _advance(self):
        self.frame_job = None
        if self.running and not self.closed:
            self.frame_index = 1 - self.frame_index
            self.face.configure(text=FRAMES[self.frame_index])
            self._schedule_frame()

    def _poll(self):
        self.poll_job = None
        for _ in range(50):
            try:
                kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "toggle":
                self.toggle()
            elif kind == "status":
                self.hotkey_status.set(value)
        if not self.closed:
            self.poll_job = self.root.after(50, self._poll)

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.running = False
        self._schedule_frame()
        if self.poll_job is not None:
            self.root.after_cancel(self.poll_job)
            self.poll_job = None
        self.hotkeys.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    PreviewApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
