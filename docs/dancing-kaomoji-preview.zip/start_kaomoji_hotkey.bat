@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto failed
echo Kaomoji hotkey preview only. No changes to LViT or the learning app.
echo Shortcut: Ctrl+Alt+Numpad1. Turn NumLock on.
py -3.11 -c "import tkinter" >nul 2>&1
if not errorlevel 1 (
    py -3.11 "%~dp0kaomoji_hotkey_preview.py"
    if errorlevel 1 goto failed
    exit /b 0
)
python -c "import sys, tkinter; assert sys.version_info >= (3, 11)" >nul 2>&1
if errorlevel 1 goto missing
python "%~dp0kaomoji_hotkey_preview.py"
if errorlevel 1 goto failed
exit /b 0
:missing
echo Python 3.11 with Tcl/Tk is required. No pip packages are needed.
pause
exit /b 1
:failed
echo Preview failed. Keep this window open and check the error above.
pause
exit /b 1
